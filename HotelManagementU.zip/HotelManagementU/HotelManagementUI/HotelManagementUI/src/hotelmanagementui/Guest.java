package hotelmanagementui;
public class Guest {
    private int id;
    private String name;
    private int roomId;

    public Guest(int id, String name, int roomId) {
        this.id = id;
        this.name = name;
        this.roomId = roomId;
    }

    public int getRoomId() {
        return roomId;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Guest: " + name + " | Room: " + roomId;
    }
}

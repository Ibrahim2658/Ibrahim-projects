package hotelmanagementui;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class HotelManagementApp extends Application {

    // Hardcoded username and password
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Login");

        // Create the login form
        VBox loginBox = new VBox(10);
        loginBox.setPadding(new Insets(20));
        loginBox.setAlignment(Pos.CENTER);

        Label userLabel = new Label("Username:");
        TextField userField = new TextField();
        userField.setPromptText("Enter username");

        Label passLabel = new Label("Password:");
        PasswordField passField = new PasswordField();
        passField.setPromptText("Enter password");

        Button loginButton = new Button("Login");
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red;");

        loginButton.setOnAction(event -> {
            String username = userField.getText();
            String password = passField.getText();

            if (USERNAME.equals(username) && PASSWORD.equals(password)) {
                // Credentials are correct, open the main app
                openMainApp(primaryStage);
            } else {
                // Show error message
                errorLabel.setText("Invalid username or password!");
            }
        });

        loginBox.getChildren().addAll(userLabel, userField, passLabel, passField, loginButton, errorLabel);

        Scene loginScene = new Scene(loginBox, 300, 200);
        primaryStage.setScene(loginScene);
        primaryStage.show();
    }

    private void openMainApp(Stage primaryStage) {
        HotelManagementUI hotelManagementUI = new HotelManagementUI();
        try {
            hotelManagementUI.start(primaryStage);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
package hotelmanagementui;

import static hotelmanagementui.HotelManagementUI.showAlert;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javafx.scene.control.Alert;

public class HotelDatabase {

    static final Map<Integer, Room> rooms = new HashMap<>();
    static final Map<Integer, Guest> guests = new HashMap<>();
    static final StringBuilder checkoutsLog = new StringBuilder();
    private static final Random random = new Random();
    private static final String[] roomTypes = {"Single", "Double", "Suite"};

    static {
        for (int i = 1; i <= 100; i++) {
            String roomType = roomTypes[random.nextInt(roomTypes.length)];
            boolean isAvailable = true;
            rooms.put(i, new Room(i, roomType, isAvailable));
        }
        for (int i = 1; i <= 20; i++) {
            String guestName = "Guest" + i;
            int roomId = i;
            rooms.get(roomId).setAvailable(false);
            Guest guest = new Guest(i, guestName, roomId);
            guests.put(i, guest);
        }
    }

    // Book a room (for rooms 21 to 100, allow manual guest ID assignment)
    public static String bookRoom(int roomId, Guest guest) {
        Room room = rooms.get(roomId);
        if (room != null && room.isAvailable()) {
            room.setAvailable(false);
            guests.put(guest.getId(), guest);
            return "Room booked successfully for " + guest.getName();
        } else {
            return "Room is not available.";
        }
    }

    // Check out a guest
// Check out a guest
public static String checkOut(int guestId) {
    Guest guest = guests.remove(guestId);
    if (guest != null) {
        Room room = rooms.get(guest.getRoomId());
        if (room != null) {
            room.setAvailable(true);
        }
        checkoutsLog.append("Checked out: ")
                    .append(guest.getName())
                    .append(" | Room: ")
                    .append(guest.getRoomId())
                    .append("\n");

        System.out.println("Checked out: " + guest.getName() + " | Room: " + guest.getRoomId());
        showAlert(Alert.AlertType.INFORMATION, "Check Out", "Guest checked out successfully.");
        return "Checked out successfully.";
    } else {
        return "Guest not found.";
    }
}

// View checkouts history
public static String viewCheckouts() {
    return checkoutsLog.length() == 0 ? "No checkouts yet." : checkoutsLog.toString();
}

    public static String bookRoom(int roomId, Guest guest, Double roomPrice) {
        Room room = rooms.get(roomId);
        if (room != null && room.isAvailable()) {
            room.setAvailable(false);
            guests.put(guest.getId(), guest);
            return "Room booked successfully for " + guest.getName() + " at a price of $" + roomPrice;
        } else {
            return "Room is not available.";
        }
    }


    // View guest list
    public static String viewGuests() {
        StringBuilder guestsList = new StringBuilder();
        for (Guest guest : guests.values()) {
            guestsList.append(guest).append("\n");
        }
        return guestsList.toString();
    }


    
    // Method to add a new guest with ID > 20
    public static String addGuest(String guestName, int roomId) {
        if (roomId < 21 || roomId > 100) {
            return "Invalid room ID. Please choose a room between 21 and 100.";
        }

        Room room = rooms.get(roomId);
        if (room == null || !room.isAvailable()) {
            return "Room is not available.";
        }

        // Find a new guest ID greater than 20
        int guestId = guests.size() + 1;
        while (guestId <= 20 || guests.containsKey(guestId)) {
            guestId++;
        }

        // Create and assign the guest
        Guest guest = new Guest(guestId, guestName, roomId);
        guests.put(guestId, guest);
        room.setAvailable(false);  // Mark the room as unavailable

        return "Guest " + guestName + " has been assigned to Room " + roomId;
    }


}

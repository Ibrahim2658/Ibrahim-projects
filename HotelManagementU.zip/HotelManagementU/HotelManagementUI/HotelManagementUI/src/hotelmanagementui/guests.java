
package hotelmanagementui;


class guests {

    static int size() {
        GuestDAO guestDAO = new GuestDAO();
        return guestDAO.getAllGuests().size(); // Return the total number of guests
    }
    
}

package hotelmanagementui;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class GuestDAO { 
    public List<Guest> getAllGuests() {
        String sql = "SELECT * FROM Guests";
        List<Guest> guests = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                guests.add(new Guest(rs.getInt("id"), rs.getString("name"), rs.getInt("room_id")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return guests;
    }

    public void deleteGuest(int guestId) {
        String sql = "DELETE FROM Guests WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, guestId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

public void addGuest(Guest guest) {
    String sql = "INSERT INTO Guests (name, room_id) VALUES (?, ?)";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, guest.getName());
        stmt.setInt(2, guest.getRoomId());
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    
    public int size() {
    return getAllGuests().size();
}
}

package hotelmanagementui;

import com.formdev.flatlaf.FlatDarkLaf; // Import FlatLaf
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javax.swing.UIManager;

public class HotelManagementUI extends Application {

    private final GuestDAO guestDAO = new GuestDAO();
    private final RoomDAO roomDAO = new RoomDAO();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Hotel Management System");

        // Create buttons
        Button btnBookRoom = createStyledButton("Book Room", "Book a room for a guest.");
        Button btnViewGuests = createStyledButton("View Guests", "View the list of current guests.");
        Button btnCheckOut = createStyledButton("Check Out", "Check a guest out of a room.");
        Button btnViewCheckouts = createStyledButton("View Checkouts", "View the history of guest checkouts.");
        Button btnExit = createStyledButton("Exit", "Exit the application.");

        // Set button actions
        btnBookRoom.setOnAction(event -> openBookingWindow());
        btnViewGuests.setOnAction(event -> viewGuests());
        btnCheckOut.setOnAction(event -> openCheckOutWindow());
        btnViewCheckouts.setOnAction(event -> viewCheckouts());
        btnExit.setOnAction(event -> primaryStage.close());

        // Use VBox for layout with padding & centering
        VBox vbox = new VBox(20, btnBookRoom, btnViewGuests, btnCheckOut, btnViewCheckouts, btnExit);
        vbox.setAlignment(Pos.CENTER);

        // Add background image to the VBox
        BackgroundImage backgroundImage = new BackgroundImage(
                new Image("file:C:\\Users\\Administrator\\Documents\\NetBeansProjects\\HotelManagementUI\\HotelImage.jpg", 714, 400, false, true), // Path to your image
                BackgroundRepeat.NO_REPEAT,
                BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                BackgroundSize.DEFAULT
        );
        vbox.setBackground(new Background(backgroundImage));

        // Create the scene with modern dimensions
        Scene scene = new Scene(vbox, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Button createStyledButton(String text, String tooltip) {
        Button button = new Button(text);
        button.setPrefWidth(200); // Consistent button width

        // Apply glossy black styling using gradients
        button.setStyle(
                "-fx-font-size: 16px; " +
                "-fx-padding: 10; " +
                "-fx-background-radius: 15; " +
                "-fx-border-radius: 15; " +
                "-fx-border-color: #333333; " +
                "-fx-border-width: 1; " +
                "-fx-text-fill: #FFFFFF; " +
                "-fx-background-color: " +
                "linear-gradient(to bottom, #666666, #000000), " + // Glossy effect
                "linear-gradient(to bottom, #000000, #111111);"   // Button base color
        );
        button.setTooltip(new Tooltip(tooltip));

        // Add hover effect for interactivity
        button.setOnMouseEntered(event -> button.setStyle(
                "-fx-font-size: 16px; " +
                "-fx-padding: 10; " +
                "-fx-background-radius: 15; " +
                "-fx-border-radius: 15; " +
                "-fx-border-color: #555555; " +
                "-fx-border-width: 1.5; " +
                "-fx-text-fill: #FFFFAA; " +
                "-fx-background-color: " +
                "linear-gradient(to bottom, #888888, #222222), " + // Lighter glossy effect
                "linear-gradient(to bottom, #222222, #333333);"   // Hovered base color
        ));

        // Restore original style when the mouse exits
        button.setOnMouseExited(event -> button.setStyle(
                "-fx-font-size: 16px; " +
                "-fx-padding: 10; " +
                "-fx-background-radius: 15; " +
                "-fx-border-radius: 15; " +
                "-fx-border-color: #333333; " +
                "-fx-border-width: 1; " +
                "-fx-text-fill: #FFFFFF; " +
                "-fx-background-color: " +
                "linear-gradient(to bottom, #666666, #000000), " +
                "linear-gradient(to bottom, #000000, #111111);"
        ));

        return button;
    }

    private void openBookingWindow() {
        Stage bookingStage = new Stage();
        bookingStage.setTitle("Book a Room");

        VBox vbox = new VBox(20);
        vbox.setPadding(new Insets(30));
        vbox.setAlignment(Pos.CENTER);

        TextField idField = new TextField();
        idField.setPromptText("Enter Guest ID");
        TextField nameField = new TextField();
        nameField.setPromptText("Enter Guest Name");

        TextField roomIdField = new TextField();
        roomIdField.setPromptText("Enter Room ID");

        Button bookButton = createStyledButton("Book Room", "Confirm room booking.");
        bookButton.setOnAction(event -> handleBooking(idField,nameField, roomIdField));

        vbox.getChildren().addAll(new Label("Guest Name:"), nameField, new Label("Room ID:"), roomIdField, bookButton);

        Scene scene = new Scene(vbox, 300, 250);
        bookingStage.setScene(scene);
        bookingStage.show();
    }

    private void handleBooking(TextField idField, TextField nameField, TextField roomIdField) {
        try {
             int id = Integer.parseInt(idField.getText());
            String guestName = nameField.getText();
            int roomId = Integer.parseInt(roomIdField.getText());
            Room room = roomDAO.getAllRooms().stream()
                    .filter(r -> r.getRoomId() == roomId && r.isAvailable())
                    .findFirst()
                    .orElse(null);

            if (room == null) {
                showAlert(Alert.AlertType.ERROR, "Room Booking Error", "Room is unavailable or does not exist.");
                return;
            }

            Guest guest = new Guest(0, guestName, roomId);
            guestDAO.addGuest(guest);
            roomDAO.updateRoomAvailability(roomId, false);
            showAlert(Alert.AlertType.INFORMATION, "Booking Successful", "Room booked successfully for " + guestName);
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid room ID. Please enter a valid number.");
        }
    }

    private void viewGuests() {
        StringBuilder guestsList = new StringBuilder();
        for (hotelmanagementui.Guest guest : guestDAO.getAllGuests()) {
            guestsList.append(guest).append("\n");
        }
        showAlert(Alert.AlertType.INFORMATION, "Guests List", guestsList.toString());
    }

    private void openCheckOutWindow() {
        Stage checkoutStage = new Stage();
        checkoutStage.setTitle("Check Out");

        VBox vbox = new VBox(20);
        vbox.setPadding(new Insets(30));
        vbox.setAlignment(Pos.CENTER);

        TextField guestIdField = new TextField();
        guestIdField.setPromptText("Enter Guest ID");

        Button checkOutButton = createStyledButton("Check Out", "Check out the guest.");
        checkOutButton.setOnAction(event -> handleCheckOut(guestIdField));

        vbox.getChildren().addAll(new Label("Guest ID:"), guestIdField, checkOutButton);

        Scene scene = new Scene(vbox, 300, 250);
        checkoutStage.setScene(scene);
        checkoutStage.show();
    }

    private void handleCheckOut(TextField guestIdField) {
        try {
            int guestId = Integer.parseInt(guestIdField.getText());
            HotelDatabase.checkOut(guestId);

           
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Invalid guest ID.");
        }
    }


    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new FlatDarkLaf());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        launch(args);
    }
    
    private void viewCheckouts() {
        String checkouts = HotelDatabase.viewCheckouts();
        showAlert(Alert.AlertType.INFORMATION, "Checkouts History", checkouts);
    }

    public static void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

}
